	#include<iostream>  
	#include<windows.h>  
	using namespace std;  	

	#define dpnum 1
	#define dnx 51
	#define dny 21

	#pragma data_seg("shared")
	double dpx[dpnum+1] = {0};
	double dpy[dpnum+1] = {0};
	double dpz[dpnum+1] = {0};
	double dpu[dpnum+1] = {0};
	double dpv[dpnum+1] = {0};
	double dpw[dpnum+1] = {0};
	double dpfx[dpnum+1] = {0};
	double dpfy[dpnum+1] = {0};
	double dpfz[dpnum+1] = {0};
	int float_flag[dpnum+1] = {0};
	double cfd_velx[dpnum+1] = {0};
	double cfd_vely[dpnum+1] = {0};
	double cfd_velz[dpnum+1] = {0};
	double cfd_h[dpnum+1] = {0};
	double cfd_z[dpnum+1] = {0};
	int grid_x[dpnum+1] = {0};
	int grid_y[dpnum+1] = {0};
	double pradius[dpnum+1] = {0};
	double grid_fx[dnx+1][dny+1] = {0};
	double grid_fy[dnx+1][dny+1] = {0};
	double grid_fz[dnx+1][dny+1] = {0};
	int cur_dpnum = dpnum;
	double cur_time = 0;
	#pragma data_seg()  
	#pragma comment(linker,"/SECTION:shared,RWS") 

	extern "C"  __declspec(dllexport) void set_cur_time(double x) 
	{  
		cur_time = x; 
	}

	extern "C"  __declspec(dllexport) void get_cur_time(double *x) 
	{  
		*x = cur_time; 
	}

	extern "C"  __declspec(dllexport) void set_particle_xyz(int i,double x, double y, double z) 
	{  
		dpx[i] = x; 
		dpy[i] = y; 
		dpz[i] = z; 
	}  

	extern "C"  __declspec(dllexport) void get_particle_xyz(int i,double *x, double *y, double *z) 
	{  
		*x = dpx[i]; 
		*y = dpy[i]; 
		*z = dpz[i]; 
	}

	extern "C"  __declspec(dllexport) void set_particle_vel(int i,double x, double y, double z) 
	{  
		dpu[i] = x; 
		dpv[i] = y; 
		dpw[i] = z; 
	}  

	extern "C"  __declspec(dllexport) void get_particle_vel(int i,double *x, double *y, double *z) 
	{  
		*x = dpu[i]; 
		*y = dpv[i]; 
		*z = dpw[i]; 
	}

	extern "C"  __declspec(dllexport) void set_particle_force(int i,double x, double y, double z) 
	{  
		dpfx[i] = x; 
		dpfy[i] = y; 
		dpfz[i] = z; 
	}

	extern "C"  __declspec(dllexport) void get_particle_force(int i,double *x, double *y, double *z) 
	{  
		*x = dpfx[i]; 
		*y = dpfy[i]; 
		*z = dpfz[i]; 
	}

	extern "C"  __declspec(dllexport) void set_particle_radius(int i,double x) 
	{  
		pradius[i] = x; 
	}

	extern "C"  __declspec(dllexport) void get_particle_radius(int i,double *x) 
	{  
		*x = pradius[i];  
	}

	extern "C"  __declspec(dllexport) void set_fluid_vel(int i,int flag,int gx, int gy, double x, double y, double z) 
	{
		float_flag[i]= flag;
		grid_x[i] = gx;
		grid_y[i] = gy;
		cfd_velx[i] = x; 
		cfd_vely[i] = y; 
		cfd_velz[i] = z; 
	}

	extern "C"  __declspec(dllexport) void set_fluid_information(int i, double x, double y) 
	{
		cfd_h[i] = x; 
		cfd_z[i] = y; 
	}

	extern "C"  __declspec(dllexport) void get_fluid_vel(int i,int *out_flag, int *flag, double *zb, double *h, double *x, double *y, double *z) 
	{
		if ( grid_x[i] == -9999 || grid_y[i] == -9999 )
		{
			*out_flag = 1;
		}
		*flag = float_flag[i];
		if ( *out_flag == 0 )
		{
			*zb = cfd_h[i];
			*h = cfd_z[i];
		}		
		*x = cfd_velx[i]; 
		*y = cfd_vely[i]; 
		*z = cfd_velz[i]; 
	}

	extern "C"  __declspec(dllexport) void set_grid_force(int i, int j,double x, double y, double z) 
	{  
		grid_fx[i][j] = x; 
		grid_fy[i][j] = y; 
		grid_fz[i][j]= z;  
	}

	extern "C"  __declspec(dllexport) void get_grid_force(int i,int j, double *x, double *y, double *z) 
	{
		*x = grid_fx[i][j]; 
		*y = grid_fx[i][j]; 
		*z = grid_fx[i][j]; 
	}

  


