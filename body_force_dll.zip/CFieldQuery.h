#if !defined(CFieldQuery_h)
#define CFieldQuery_h

#include <string>

#include "Helpers.h"

#include "IPluginParticleBodyForceV2_2_0.h"

namespace NApiCore
{
	class IFieldManagerApi_1_0;
	class IFieldApi_1_0;
};

/**
 * This class provides an implementation of IPluginParticleBodyForceV2_0_0
 * That applies an fluid drag force to particles based on imported
 * field data.
 *
 * This plugin reads a config file from the same directory as
 * it is stored in.  The file format is as follows (1 line per value):
 *     density
 *     viscosity
 *
 * NOTE: This version of the field query and fluid drag code is provided
 * only as an example of how to create a particle body force
 * plugin and is not updated on a regular basis.
 */
class CFieldQuery : public NApiPbf::IPluginParticleBodyForceV2_2_0
{
    public:
        /**
         * Name of the preferences file to load fluid drag information
         */
        static const std::string PREFS_FILE;

        /**
         * Constructor, does nothing
         */
        CFieldQuery();

        /**
         * Destructor, does nothing
         */
        virtual ~CFieldQuery();

        /**
         * Sets prefFileName to PREFS_FILE
         *
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
        virtual void getPreferenceFileName(char prefFileName[NApi::FILE_PATH_MAX_LENGTH]);

        /**
         * Returns true to indicate plugin is thread safe
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
        virtual bool isThreadSafe();

        /**
         * Returns false to indicate the plugin does not use custom properties
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
        virtual bool usesCustomProperties();

        /**
         * Reads config file
         *
         * Implementation of method from IPluginParticleBodyForceV2_2_0
         */

         virtual bool setup(NApiCore::IApiManager_1_0& apiManager,
                           const char                 prefFile[],
                           char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH]);
		/**
         * Does nothing
         *
         * Implementation of method from IPluginParticleBodyForceV2_2_0
         */
        virtual bool starting(NApiCore::IApiManager_1_0& apiManager, int numThreads);


        /**
         * Does nothing
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
        virtual void stopping(NApiCore::IApiManager_1_0& apiManager);

        /**
         * Applies an fluid drag force to particles
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
        virtual NApi::ECalculateResult externalForce(
                                           int          threadId,
                                           double       time,
                                           double       timestep,
                                           int          id,
                                           const char   type[],
                                           double       mass,
                                           double       volume,
                                           double       density,
                                           unsigned int surfaces,
                                           double       posX,
                                           double       posY,
                                           double       posZ,
                                           double       velX,
                                           double       velY,
                                           double       velZ,
                                           double       angVelX,
                                           double       angVelY,
                                           double       angVelZ,
                                           double       charge,
                                           const double orientation[9],
                                           NApiCore::ICustomPropertyDataApi_1_0* particlePropData,
                                           NApiCore::ICustomPropertyDataApi_1_0* simulationPropData,
                                           double&      calculatedForceX,
                                           double&      calculatedForceY,
                                           double&      calculatedForceZ,
                                           double&      calculatedTorqueX,
                                           double&      calculatedTorqueY,
                                           double&      calculatedTorqueZ);

        /**
         * Returns 1 to indicate the plugin wishes to register 1 property
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
		virtual unsigned int getNumberOfRequiredProperties(
                                const NApi::EPluginPropertyCategory category);
        /**
         * Returns details for the residence time property
         *
         * Implementation of method from IPluginParticleBodyForceV2_1_0
         */
        virtual bool getDetailsForProperty(
                         unsigned int                    propertyIndex,
                         NApi::EPluginPropertyCategory   category,
                         char                            name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
                         NApi::EPluginPropertyDataTypes& dataType,
                         unsigned int&                   numberOfElements,
                         NApi::EPluginPropertyUnitTypes& unitType,
                         char                            initValBuff[NApi::BUFF_SIZE]);

    private:
        double                          m_dragCoefficient;
        double                          m_density;
		double                          m_viscosity;
		NApiCore::IFieldManagerApi_1_0* m_fieldManager;
		NApiCore::IFieldApi_1_0*        m_field;
};

#endif
