#include "CFieldQuery.h"
#include "IFieldApi_1_0.h"
#include "IFieldManagerApi_1_0.h"
#include "IApiManager_1_0.h"
#include <fstream>
#include <windows.h>
#include <stdio.h>
#include <io.h>

using namespace std;
using namespace NApi;
using namespace NApiCore;
using namespace NApiPbf;

const string CFieldQuery::PREFS_FILE = "field_query_prefs.txt";

CFieldQuery::CFieldQuery():
m_fieldManager(0), m_field(0)
{
    ;
}

CFieldQuery::~CFieldQuery()
{
    ;
}

void CFieldQuery::getPreferenceFileName(char prefFileName[FILE_PATH_MAX_LENGTH])
{
    // Copy in pref file name
    strcpy(prefFileName, PREFS_FILE.c_str());
}

bool CFieldQuery::isThreadSafe()
{
    // thread safe
    return true;
}

bool CFieldQuery::usesCustomProperties()
{
    // Use custom properties
    return true;
}

bool CFieldQuery::setup(NApiCore::IApiManager_1_0& apiManager,
                           const char                 prefFile[],
                           char                       customMsg[NApi::ERROR_MSG_MAX_LENGTH])
{
	//This is executed during the loading of the plugin
	//Open the preference file
    ifstream prefsFile(prefFile);

    if(!prefsFile)
    {
        return false;
    }
    else
    {
		//Reading in the parameters in the file
        prefsFile >> m_density
				  >> m_viscosity;
    }

    return true;
}

bool CFieldQuery::starting(NApiCore::IApiManager_1_0& apiManager, int numThreads)
{
    return true;
}

void CFieldQuery::stopping(NApiCore::IApiManager_1_0& apiManager)
{

}

ECalculateResult CFieldQuery::externalForce(
                                           int          threadId,
                                           double       time,
                                           double       timestep,
                                           int          id,
                                           const char   type[],
                                           double       mass,
                                           double       volume,
                                           double       density,
                                           unsigned int surfaces,
                                           double       posX,
                                           double       posY,
                                           double       posZ,
                                           double       velX,
                                           double       velY,
                                           double       velZ,
                                           double       angVelX,
                                           double       angVelY,
                                           double       angVelZ,
                                           double       charge,
                                           const double orientation[9],
                                           NApiCore::ICustomPropertyDataApi_1_0* particlePropData,
                                           NApiCore::ICustomPropertyDataApi_1_0* simulationPropData,
                                           double&      calculatedForceX,
                                           double&      calculatedForceY,
                                           double&      calculatedForceZ,
                                           double&      calculatedTorqueX,
                                           double&      calculatedTorqueY,
                                           double&      calculatedTorqueZ)
{

	int out_flag = 0;
	int float_flag = 0;
	double cur_time = 0.0;
	double cfdzb = 0.0;       
	double cfdh = 0.0;        
	double Pzb = 0.0;      
	double porosity = 1.0;
	double n = 1.0;           

	//Calculate radius of particle (assuming spherical)
	double nRadius = pow( 3.0 * volume / ( 4.0 * PI ),1.0 / 3.0 );

	//Calculate cross sectional area of particle
	double nCSA =  PI * nRadius * nRadius;

	//create variables for the CFD Field
	double cfdFieldX, cfdFieldY, cfdFieldZ;

	typedef void ( _cdecl * set_time)(double ); 
	typedef void ( _cdecl * get_time)(double *);
	typedef void ( _cdecl * set_radius)(int,double);
	typedef void ( _cdecl * set)(int,double, double, double); 
	typedef void ( _cdecl * get)(int k,int *,int *,double *, double *,double *, double *);
	typedef void ( _cdecl * get_vel)(int k,int *,int *, double *, double *,double *,double *, double *); 

	HINSTANCE hMod=LoadLibrary(TEXT("shared_dll.dll"));
	if(hMod==NULL)
		 {
		  //cout<<"can't find the dll file"<<endl;
		 }

	set_time set_cur_time=(set_time) GetProcAddress(hMod,"set_cur_time");
	set_radius set_particle_radius=(set_radius) GetProcAddress(hMod,"set_particle_radius");
	get_time get_cur_time=(get_time) GetProcAddress(hMod,"get_cur_time");
	set set_particle_xyz=(set) GetProcAddress(hMod,"set_particle_xyz");
	set set_particle_vel=(set) GetProcAddress(hMod,"set_particle_vel");
	set set_particle_force=(set) GetProcAddress(hMod,"set_particle_force");
	get_vel get_fluid_vel=(get_vel) GetProcAddress(hMod,"get_fluid_vel");

	get_cur_time(&cur_time);
	
	if(time==0)
	{
		set_particle_radius(id,nRadius);
	}
	
	if (time>cur_time+timestep-1e-10)
	{
		ShellExecute(NULL,L"open",L"cmd.exe",L"/c del edem.txt",L"",SW_HIDE);
		ShellExecute(NULL,L"open",L"cmd.exe",L"/c type nul>massflow.txt",L"",SW_HIDE); 
	}

	FILE *fp;
	while( (fp = fopen("edem.txt","r"))==NULL)
	{
		
	}
	fclose(fp);

	get_cur_time(&cur_time);

	if (time>cur_time-timestep)
	{
		set_particle_xyz(id,posX,posY,posZ);
		set_particle_vel(id,velX,velY,velZ);
	}

	get_fluid_vel(id,&out_flag,&float_flag,&cfdzb,&cfdh,&cfdFieldX,&cfdFieldY,&cfdFieldZ);

	if (float_flag == 1) 
	{

		if ( posZ <= (cfdzb + cfdh) )
		{	
			cfdFieldX = ( ( n+1.0 ) * cfdFieldX / pow( cfdh, n ) ) * pow( ( posZ - cfdzb ), n );           
			cfdFieldY = ( ( n+1.0 ) * cfdFieldY / pow( cfdh, n ) ) * pow( ( posZ - cfdzb ), n );  
			cfdFieldZ = ( ( n+1.0 ) * cfdFieldY / pow( cfdh, n ) ) * pow( ( posZ - cfdzb ), n );  
		}
		else 
		{	
			cfdFieldX = 0.0;
			cfdFieldY = 0.0;
			cfdFieldZ = 0.0;
		}

		//Define the direction of Gravity
		CSimple3DVector gravity(0.0,0.0,-9.81);

		//Apply a Buoyancy force to the particle
		CSimple3DVector F_buoyancy = gravity * volume * m_density;


		if ( out_flag == 0 && float_flag == 1 && posZ < ( cfdzb + cfdh )  )
		{	
			calculatedForceX +=  -F_buoyancy.dx();
			calculatedForceY +=  -F_buoyancy.dy();
			calculatedForceZ +=  -F_buoyancy.dz();
		}

		////STEP 2 - Convert the fluid velocity to a Vector called cfdField
		CSimple3DVector cfdField(cfdFieldX,cfdFieldY,cfdFieldZ);

		//STEP 3 - Define the particle velocity vector
		CSimple3DVector particleVelocity(velX, velY, velZ);

		//STEP 4 - Find the relative velocity between particle and fluid
		CSimple3DVector relativeVelocity = cfdField - particleVelocity;

		//Find Local Reynolds number using the relative velocity
		double re = m_density * relativeVelocity.length() * 2.0 * nRadius / m_viscosity;

		//STEP 5 - Calculate the drag force on the particle

		CSimple3DVector F_drag;

		//Di Felice
		if( !isZero(re) )
		{
			m_dragCoefficient = pow( (0.63 + 4.8 / sqrt(re)) , 2.0 );
		}

		double porosity_correction = 3.7 - 0.65 * pow(2.718282,(-pow((1.5 - log(re)),2.0) / 2));  

		F_drag =  relativeVelocity
				  * 0.5
		   		  * m_dragCoefficient
				  * nCSA
				  * m_density
				  * relativeVelocity.length()
				  * pow(porosity,1-porosity_correction);

		if (time>cur_time-timestep)
		{
			if ( out_flag == 0 && float_flag == 1 && posZ < ( cfdzb + cfdh ) )
			{
				set_particle_force(id,F_drag.dx(),F_drag.dy(),F_drag.dz());
			}
			else
			{ 
				set_particle_force(id,F_drag.dx(),F_drag.dy(),F_drag.dz());
			}
		}

		//Return the force to EDEM
		if ( out_flag == 0 && float_flag == 1 && posZ < ( cfdzb + cfdh ) ) 
		{
			calculatedForceX += F_drag.dx();
			calculatedForceY += F_drag.dy();
			calculatedForceZ += F_drag.dz(); 
		}

	}

    return eSuccess;
}

unsigned int CFieldQuery::getNumberOfRequiredProperties(
                                const NApi::EPluginPropertyCategory category)
{
	return 0;
}

bool CFieldQuery::getDetailsForProperty(
                         unsigned int                    propertyIndex,
                         NApi::EPluginPropertyCategory   category,
                         char                            name[NApi::CUSTOM_PROP_MAX_NAME_LENGTH],
                         NApi::EPluginPropertyDataTypes& dataType,
                         unsigned int&                   numberOfElements,
                         NApi::EPluginPropertyUnitTypes& unitType,
                         char                            initValBuff[NApi::BUFF_SIZE])
{
	return false;
}